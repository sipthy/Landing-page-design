new Splide(".splide", {
  perPage: 3,
  breakpoints: {
    640: {
      perPage: 2,
      gap: "1rem",
    },
    480: {
      perPage: 1,
      gap: "1rem",
    },
  }, 
}).mount();


// Google sheet
/*const scriptURL = "https://script.google.com/macros/s/AKfycbx3v_H-2vb_AwW3S-ox7_cScuwC6DWas-XuyJ3BVN4j928itlEOKopJ19qs_Kaz9HJ8/exec";
const form = document.querySelector("form");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  fetch(scriptURL, { method: "POST", body: new FormData(form) })
    .then((response) => console.log(response))
    .catch((error) => console.error("Error!", error.message));
});*/

// Data to telegram and mail(form.php)
function telegram_send_data() {
 
  var name1 = document.getElementById("hema_name");
  var email1 = document.getElementById("hema_email");
  var contact1 = document.getElementById("hema_contact");
  var message1 = document.getElementById("hema_message");
  
   const namevalidate = /^[a-zA-Z . ]+(?:\s+[a-zA-Z]+)*$/;
    const phonenovalidate = /^[6-9]+\d{9}$/;
    const mailvalidate = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})/;
    const qtyvalidate = /^(\d)|(\d+\.+\d*)/;
  // values
  var username = name1.value;
  var Name = username.toLowerCase();
  var Email= email1.value;
  var Contact = contact1.value;
  var Message= message1.value;
  var information="contactFrmSubmit=1&Name=" +
        Name +
        "&Email=" +
        Email +
        "&Contact=" +
        Contact +
        "&Message=" +
        Message;

  if (namevalidate.test(Name) && mailvalidate.test(Email) && phonenovalidate.test(Contact) && qtyvalidate.test(Message)) {
      $.ajax({
    type: "POST",
    url: "https://script.google.com/macros/s/AKfycbx3v_H-2vb_AwW3S-ox7_cScuwC6DWas-XuyJ3BVN4j928itlEOKopJ19qs_Kaz9HJ8/exec",
    data: information,
  });

    $.ajax({
      type: "POST",
      url: "form.php",
      data: information,
         beforeSend: function(){
          $('#output').html("Form is submitting....");
        },  
   success: function(data){
      window.location = "https://hemajewellers.in/thank-you/";
     },        
    });
  }else {

     alert("Kindly Fill The Form Properly ");
    
  }
}
   
   
  

